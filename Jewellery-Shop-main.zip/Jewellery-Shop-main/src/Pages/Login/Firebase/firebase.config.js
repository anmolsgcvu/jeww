/* const firebaseConfig = {
    apiKey: process.env.REACT_APP_FIREBASE_API_KEY,
    authDomain: process.env.REACT_APP_FIREBASE_AUTH_DOMAIN,
    projectId: process.env.REACT_APP_FIREBASE_PROJECT_ID,
    storageBucket: process.env.REACT_APP_FIREBASE_STORAGE_BUCKET,
    messagingSenderId: process.env.REACT_APP_FIREBASE_MESSAGINGSENDER_ID,
    appId: process.env.REACT_APP_FIREBASE_APP_ID,
};
 */

const firebaseConfig = {
    apiKey: "AIzaSyDI_89gOyiDWxlyQZKLUw8FatM-9EU3M5Y",
    authDomain: "jewellery-ec2de.firebaseapp.com",
    projectId: "jewellery-ec2de",
    storageBucket: "jewellery-ec2de.appspot.com",
    messagingSenderId: "663953010506",
    appId: "1:663953010506:web:a16437b952c6602f47dbb3"
};

export default firebaseConfig;